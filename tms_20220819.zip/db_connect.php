<?php 

$conn= new mysqli('srv89.niagahoster.com','u8824069_tms','P@ssw0rd123456','u8824069_tms')or die("Could not connect to mysql".mysqli_error($con));
// $conn= new mysqli('localhost','root','','tms_db')or die("Could not connect to mysql".mysqli_error($con));

